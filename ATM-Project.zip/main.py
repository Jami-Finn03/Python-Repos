name=input("What is your name?:\n")
b=12000
def atm(b):
    print("You have a balance of: ", b)
    wd=input("Would you like to make a withdraw or deposit?\nPlease enter a 'W' for withdrawal, or a 'D' for deposit:\n")
    if(wd.lower()=="w"):
      a=int(input("please enter an amount: \n"))
      if(a<12001):
        b=b-a
        print("your new balance is",b)
        yn=input("would you like to make another transaction?\n enter 'Y' for yes, or 'N' for no:\n ")
        if(yn.lower()=="y"):
          atm(b)
        elif(yn.lower()=="n"):
            print("goodbye.")
      elif(a>12001):
        print("insuffiecent funds ", b)
    elif(wd.lower()=="d"):
      A=int(input("please enter an amount: "))
      if(A<5000):
        b=b+A
        print("your new balance is",b)
        Yn=input("would you like to make another transaction?\n enter 'Y' for yes, or 'N' for no:\n ")
        if(Yn.lower()=="y"):
          atm(b)
        elif(Yn.lower()=="n"):
            print("goodbye.")
      elif(A>4999):
        ID=input("Do you have an ID? enter 'Y' for yes, or 'N' for no:\n ")
        if(ID.lower()=="y"):
          b=b+A
          print("your new balance is",b)
          z=input("would you like to make another transaction?\n enter 'Y' for yes, or 'N' for no:\n ")
          if(z.lower()=="y"):
            atm(b)
          elif(z.lower()=="n"):
              print("goodbye.")
        elif(ID.lower()=="n"):
          print("You need an ID to deposit that amount")
    elif(wd.lower() != "d" or wd.lower() != "w"):
      print("Please enter a 'W' or 'D' next time\nif you are just checking your balance, download our app!")
      atm(b)
atm(b)