import turtle
def r():
  r=turtle.Turtle()
  r.color("sienna")
  r.fillcolor("red")

  r.begin_fill()
  for i in range(2):
    r.forward(160)
    r.right(90)
    r.forward(300)
    r.right(90)
  r.end_fill()
  r.hideturtle()
r()
def w():
  w=turtle.Turtle()
  w.color("sienna")
  w.fillcolor("ivory")

  w.goto(160,0)
  w.begin_fill()
  for i in range(2):
    w.forward(230)
    w.left(90)
    w.backward(300)
    w.left(90)
  w.end_fill()
  w.hideturtle()
w()
def r2():
  r2=turtle.Turtle()
  r2.color("sienna")
  r2.fillcolor("red")

  r2.goto(390,0)
  r2.begin_fill()
  for i in range(2):
    r2.forward(160)
    r2.right(90)
    r2.forward(300)
    r2.right(90)
  r2.end_fill()
  r2.hideturtle()
r2()
def ml():
  ml=turtle.Turtle()
  ml.color("red")
  ml.fillcolor("red")


  ml.penup()
  ml.goto(275,-240)
  ml.left(90)
  ml.begin_fill()
  ml.pendown()
  ml.forward(45)#maple leaf
  ml.left(110)
  ml.width(1)
  ml.forward(30)#first bit of leaf 19
  ml.right(120)#18
  ml.forward(20)#18
  ml.left(70)#17
  ml.forward(50)#16
  ml.right(120)
  ml.forward(15)
  ml.left(75)
  ml.forward(30)
  ml.right(135)
  ml.forward(30)
  ml.left(120)
  ml.forward(15)
  ml.right(135)
  ml.forward(35)#here
  ml.left(135)
  ml.forward(45)
  ml.right(135)
  ml.forward(15)
  ml.left(120)
  ml.forward(30)
  ml.right(150)
  #THIS IS WHERE IT SCREWS UP
  ml.forward(30)
  ml.left(120)
  ml.forward(15)
  ml.right(135)
  ml.forward(45)
  ml.left(135)
  ml.forward(35)#pause to look
  ml.right(135)
  ml.forward(15)
  ml.left(120)
  ml.forward(30)
  ml.right(135)
  ml.forward(30)
  ml.left(75)
  ml.forward(15)#16
  ml.right(120)#17
  ml.forward(50)#18
  ml.left(70)#18
  ml.forward(20)#first bit of leaf 19
  ml.right(120)
  ml.forward(30)
  ml.left(110)
  ml.forward(45)
  ml.right(90)
  ml.forward(15)
  ml.end_fill()

  ml.hideturtle()
ml()