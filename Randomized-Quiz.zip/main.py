import random
score=int(100)
name=input("Enter your name: ")

def Q1(): 
  print("What color are Harry Potter's eyes? ")
  A1= input("A.{}\nB.{}\nC.{}\nD.{}\nanswer: ".format("blue","hazel","green","brown"))
  if(A1.lower()=="c"):
    print("Yeah, you're right.")
    print(" ")
  else:
    print("you're wrong! -10 off your score!")
    print(" ")
    global score
    score=score-10
def Q2():
  print("How many books are there in the Harry Potter series? ")
  A2= input("A.{}\nB.{}\nC.{}\nD.{}\nanswer: ".format("10","9","8","7"))
  if(A2.lower()=="d"):
    print("Yeah, you're right.")
    print(" ")
  else:
    print("you're wrong! -10 off your score!")
    print(" ")
    global score
    score=score-10
def Q3():
  print("Who is the president of the United States as of 2019?")
  A3= input("A.{}\nB.{}\nC.{}\nD.{}\nanswer: ".format("Hilary","Obama","Ghandi","Trump"))
  if(A3.lower()=="d"):
    print("Yeah, you're right.")
    print(" ")
  else:
    print("you're wrong! -10 off your score!")
    print(" ")
    global score
    score=score-10
def Q4():
  print("How many colors are in a rainbow? ")
  A4= input("A.{}\nB.{}\nC.{}\nD.{}\nanswer: ".format("12","60","7","100"))
  if(A4.lower()=="c"):
    print("Yeah, you're right.")
    print(" ")
  else:
    print("you're wrong! -10 off your score!")
    print(" ")
    global score
    score=score-10
def Q5():
  print("How many keys on a piano? ")
  A5= input("A.{}\nB.{}\nC.{}\nD.{}\nanswer: ".format("88","85","22","4"))
  if(A5.lower()=="a"):
    print("Yeah, you're right.")
    print(" ")
  else:
    print("you're wrong! -10 off your score!")
    print(" ")
    global score
    score=score-10
def Q6():
  print("How many colors are in the America Flag? ")
  A6= input("A.{}\nB.{}\nC.{}\nD.{}\nanswer: ".format("63","3","2","7"))
  if(A6.lower()=="b"):
    print("Yeah, you're right.")
    print(" ")
  else:
    print("you're wrong! -10 off your score!")
    print(" ")
    global score
    score=score-10
def Q7():
  print("How many characters are in the alphabet? ")
  A7= input("A.{}\nB.{}\nC.{}\nD.{}\nanswer: ".format("23","25","26","4"))
  if(A7.lower()=="c"):
    print("Yeah, you're right.")
    print(" ")
  else:
    print("you're wrong! -10 off your score!")
    print(" ")
    global score
    score=score-10
def Q8():
  print("How many colors are on the tricolore? ")
  A8= input("A.{}\nB.{}\nC.{}\nD.{}\nanswer: ".format("3","2","1","0"))
  if(A8.lower()=="a"):
    print("Yeah, you're right.")
    print(" ")
  else:
    print("you're wrong! -10 off your score!")
    print(" ")
    global score
    score=score-10
def Q9():
  print("What's the past tense of yeet? ")
  A9= input("A.{}\nB.{}\nC.{}\nD.{}\nanswer: ".format("yeeted","yote","yeet","no"))
  if(A9.lower()=="b"):
    print("Yeah, you're right.")
    print(" ")
  else:
    print("you're wrong! -10 off your score!")
    print(" ")
    global score
    score=score-10
def Q10():
  print("1+1= ")
  A10= input("A.{}\nB.{}\nC.{}\nD.{}\nanswer: ".format("2","chicken","fish","cat"))
  if(A10.lower()=="a"):
    print("Yeah, you're right.")
    print(" ")
  else:
    print("you're wrong! -10 off your score!")
    print(" ")
    global score
    score=score-10


y=[Q1,Q2,Q3,Q4,Q5,Q6,Q7,Q8,Q9,Q10]
x=0

def z(score):
  print("~~~~~~")
  print("WELCOME TO THE TEST")
  print("~~~~~~")
  y=[Q1,Q2,Q3,Q4,Q5,Q6,Q7,Q8,Q9,Q10]
  x=0
  while(x!=10):
    x=x+1
    run=random.choice(y)
    run()
    y.remove(run)
z(score)


s=print(name,"... you made a", score)
if(score<60 or score==60):
  print("~~~~~~")
  print("You need to try again, {}, your grade is too low!".format(name))
  print("Test restarting.....")
  print("~~~~~~")
  z(score)